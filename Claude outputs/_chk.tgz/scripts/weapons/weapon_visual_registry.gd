# =============================================================================
# weapon_visual_registry.gd
# Registro Central de Modelos 3D, Apresentação e Gunsmith Modular
# Fornece modelos individuais, alinhamento calibrado e montagem 3D de acessórios
# para todas as 18 armas do arsenal.
# =============================================================================
class_name WeaponVisualRegistry
extends RefCounted

# Dicionário de calibração e caminhos individuais por ID de arma
static var REGISTRY: Dictionary = {
	# ── FUZIS DE ASSALTO ──────────────────────────────────────────────────────
	"acr68": {
		"name": "ACR 6.8",
		"category": "ar",
		"scene": "res://scenes/weapons/modular/acr68.tscn",
		"scale": 0.52,
		"vm_scale": 0.98,
		"vm_offset": Vector3(1.5285, 1.1572, 11.8376), # mão no cabo real (tools_capture/grip_fit, ajuste -2.5 cm)
		"hip_offset": Vector3(-0.092, -0.315, 0.360),
		"ads_depth": -0.44,
		"ads_depth_optic": -0.38,
		"model_rotation": Vector3(0, 0, 0),
		"vm_rotation": Vector3(2.0, -2.5, 0.5),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0846, 0.0770, -0.1250), # mão de apoio: c clamp guarda mao (tools_capture/support_fit, palma medida após o IK)
		# Encaixe feito no Blender (pipeline estilo CoD): gatilho sob a polpa do indicador da pose original do addon,
		# cano paralelo ao da AK original e escala real (117 un/m). Matriz do glb da arma em relação ao nó "base".
		"rig_fit": Transform3D(Basis(Vector3(-117.023415, -0.477971, -0.000018), Vector3(-0.477971, 117.023384, 0.0), Vector3(0.000018, 0.0, -117.024361)), Vector3(0.772975, 3.208940, 17.324545)),
		# modelo sem mira de ferro (só trilho): alça e massa rebatíveis montadas no trilho quando não há ótica (como no CoD)
		"ads_rear": Vector3(0.0064, 0.145, 0.15), "ads_front": Vector3(0.0064, 0.145, -0.27), "ads_eye": 0.09,
		"buis": {"rail_y": 0.123, "x": 0.0064, "rear_z": 0.15, "front_z": -0.27, "line_y": 0.145},
		"cuts": [{"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.195), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"has_arms": false,
		"socket_optic": Vector3(0.0064, 0.1650, 0.0260),
		"socket_muzzle": Vector3(0.0064, 0.0430, -0.2750),
		"socket_mag": Vector3(0.0064, -0.0183, -0.0260),
		"socket_underbarrel": Vector3(0.0064, -0.0030, -0.1300),
		"socket_stock": Vector3(0.0064, 0.0430, 0.2300),
		"socket_rear_grip": Vector3(0.0064, -0.0290, 0.0780),
		"socket_iron_ads": Vector3(0.0064, 0.1820, 0.1832)
	},
	"ak47": {
		"name": "ACR 6.8",
		"category": "ar",
		"scene": "res://scenes/weapons/modular/acr68.tscn",
		"scale": 0.52,
		"vm_scale": 0.98,
		"vm_offset": Vector3(1.5274, 1.1582, 11.8637), # mão no cabo real (tools_capture/grip_fit, ajuste -2.5 cm)
		"hip_offset": Vector3(-0.092, -0.315, 0.360),
		"ads_depth": -0.44,
		"ads_depth_optic": -0.38,
		"model_rotation": Vector3(0, 0, 0),
		"vm_rotation": Vector3(2.0, -2.5, 0.5),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0883, 0.0716, -0.1397), # mão de apoio: c clamp guarda mao (tools_capture/support_fit, palma medida após o IK)
		# Encaixe feito no Blender (pipeline estilo CoD): gatilho sob a polpa do indicador da pose original do addon,
		# cano paralelo ao da AK original e escala real (117 un/m). Matriz do glb da arma em relação ao nó "base".
		"rig_fit": Transform3D(Basis(Vector3(-117.023415, -0.477971, -0.000018), Vector3(-0.477971, 117.023384, 0.0), Vector3(0.000018, 0.0, -117.024361)), Vector3(0.772975, 3.208940, 17.324545)),
		# modelo sem mira de ferro (só trilho): alça e massa rebatíveis montadas no trilho quando não há ótica (como no CoD)
		"ads_rear": Vector3(0.0064, 0.145, 0.15), "ads_front": Vector3(0.0064, 0.145, -0.27), "ads_eye": 0.09,
		"buis": {"rail_y": 0.123, "x": 0.0064, "rear_z": 0.15, "front_z": -0.27, "line_y": 0.145},
		"cuts": [{"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.195), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"has_arms": false,
		"socket_optic": Vector3(0.0064, 0.1650, 0.0260),
		"socket_muzzle": Vector3(0.0064, 0.0430, -0.2750),
		"socket_mag": Vector3(0.0064, -0.0183, -0.0260),
		"socket_underbarrel": Vector3(0.0064, -0.0030, -0.1300),
		"socket_stock": Vector3(0.0064, 0.0430, 0.2300),
		"socket_rear_grip": Vector3(0.0064, -0.0290, 0.0780),
		"socket_iron_ads": Vector3(0.0064, 0.1820, 0.1832)
	},
	"m4a1": {
		"name": "M4A1",
		"category": "ar",
		"scene": "res://scenes/weapons/modular/m4a1.tscn",
		"scale": 0.52,
		"vm_scale": 0.84,
		"vm_offset": Vector3(-0.0000, 2.2000, 1.1195), # mão no cabo real (tools_capture/grip_fit, ajuste 3.6 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.092, -0.315, 0.360),
		"ads_depth": -0.36,
		"model_rotation": Vector3(-0.572, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0860, 0.0403, -0.0116), # mão de apoio: empunhadura embutida (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.023415, -0.477971, -0.000010), Vector3(-0.477971, 117.023384, 0.000000), Vector3(0.000010, 0.000000, -117.024361)), Vector3(2.698946, 1.555046, 23.994934)), # Blender: gatilho sob o indicador da pose original (família AK)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 8 cm da alça (uso real / CoD)
		"ads_rear": Vector3(0.023, 0.1485, 0.186), "ads_front": Vector3(0.023, 0.1485, -0.223), "ads_eye": 0.08,
		# desvio lateral real do modelo: +0.0230 m (rig_fit deslocado para o gatilho real ficar sob o dedo)
		"cuts": [{"slot": "underbarrel", "mesh": "reargrip", "min": Vector3(-1, -1, -1), "max": Vector3(1, 1, -0.05)}, {"slot": "grip", "mesh": "reargrip", "min": Vector3(-1, -1, 0.05), "max": Vector3(1, 1, 1)}], # empunhadura e cabo na mesma malha
		"has_arms": false,
		"socket_optic": Vector3(0.0221, 0.1344, 0.0250),
		"socket_muzzle": Vector3(0.0221, 0.0653, -0.4250),
		"socket_mag": Vector3(0.0221, 0.0880, 0.0530),
		"socket_underbarrel": Vector3(0.0221, 0.0049, -0.1890),
		"socket_stock": Vector3(0.0221, 0.0450, 0.1516),
		"socket_rear_grip": Vector3(0.0221, -0.0404, 0.1470),
		"socket_iron_ads": Vector3(0.0221, 0.1595, 0.1694)
	},
	"scar_h": {
		"name": "SCAR-H",
		"category": "ar",
		"scene": "res://scenes/weapons/modular/scar_h.tscn",
		"scale": 0.53,
		"vm_scale": 0.88,
		"vm_offset": Vector3(0.0000, 2.2000, 3.5288), # mão no cabo real (tools_capture/grip_fit, ajuste -0.5 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.092, -0.315, 0.360),
		"ads_depth": -0.36,
		"model_rotation": Vector3(0, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0884, 0.0582, -0.0513), # mão de apoio: c clamp guarda mao (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.023415, -0.477971, -0.000010), Vector3(-0.477971, 117.023384, 0.000000), Vector3(0.000010, 0.000000, -117.024361)), Vector3(0.074029, 5.289135, 18.974588)), # Blender: gatilho sob o indicador da pose original (família AK)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 8 cm da alça (uso real / CoD)
		"ads_rear": Vector3(-0.002, 0.128, 0.176), "ads_front": Vector3(-0.002, 0.128, -0.2016), "ads_eye": 0.08, # centro do capuz da massa
		"cuts": [{"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.215), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"has_arms": false,
		"socket_optic": Vector3(0, 0.0957, 0.0265),
		"socket_muzzle": Vector3(0, 0.0442, -0.2800),
		"socket_mag": Vector3(0, -0.0204, -0.0265),
		"socket_underbarrel": Vector3(0, -0.0042, -0.1325),
		"socket_stock": Vector3(0, 0.0442, 0.2350),
		"socket_rear_grip": Vector3(0, -0.0317, 0.0795),
		"socket_iron_ads": Vector3(0, 0.1490, 0.1829)
	},
	"man_o_war": {
		"name": "Man-O-War",
		"category": "ar",
		"scene": "res://scenes/weapons/modular/man_o_war.tscn",
		"scale": 0.53,
		"vm_scale": 0.86,
		"vm_offset": Vector3(-0.0000, 2.0000, 2.4265), # mão no cabo medido no Blender (ajuste 0.9 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.092, -0.335, 0.430), # bullpup: conjunto mais à frente e abaixo (padrão CoD)
		"ads_depth": -0.36,
		"model_rotation": Vector3(0, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0878, 0.0507, -0.0982), # mão de apoio: c clamp guarda mao bullpup (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.023415, -0.477971, -0.000010), Vector3(-0.477971, 117.023384, 0.000000), Vector3(0.000010, 0.000000, -117.024361)), Vector3(-0.008364, 5.405824, 5.785941)), # Blender: gatilho sob o indicador da pose original (família AK)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 8 cm da alça (uso real / CoD)
		"ads_rear": Vector3(-0.002, 0.171, 0.097), "ads_front": Vector3(-0.002, 0.171, -0.072), "ads_eye": 0.22, # janela grande: olho mais atrás
		"sight_dot": Vector3(-0.002, 0.171, -0.07), # ponto vermelho da mira embutida (sem ótica)
		# vidro da mira embutida faz parte da malha "Sight": triângulos de frente para o cano dentro da janela viram vidro translúcido
		"sight_glass": {"mesh": "Sight", "x0": -0.038, "x1": 0.034, "y0": 0.120, "y1": 0.205},
		"cuts": [{"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.405), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"grip_side": "front", # bullpup: cabo à frente do pente
		"has_arms": false,
		"socket_optic": Vector3(0, 0.1418, 0.0265),
		"socket_muzzle": Vector3(0, 0.0580, -0.2800),
		"socket_mag": Vector3(0, -0.0434, -0.0265),
		"socket_underbarrel": Vector3(0, -0.0180, -0.1325),
		"socket_stock": Vector3(0, 0.0580, 0.2350),
		"socket_rear_grip": Vector3(0, -0.0612, 0.0795),
		"socket_iron_ads": Vector3(0, 0.2218, 0.0552)
	},

	# ── SUBMETRALHADORAS ──────────────────────────────────────────────────────
	"mp7": {
		"name": "MP7",
		"category": "smg",
		"scene": "res://scenes/weapons/modular/mp7.tscn",
		"scale": 0.44,
		"vm_scale": 0.58,
		"vm_offset": Vector3(0.0000, 1.5000, 5.6001), # mão no cabo real (tools_capture/grip_fit, ajuste -2.4 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.075, -0.280, 0.345),
		"ads_depth": -0.36,
		"model_rotation": Vector3(0, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0017, 0.0338, 0.0614), # mão de apoio: c clamp guarda mao (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.024391, 0.000000, -0.000010), Vector3(0.000000, 117.024361, 0.000000), Vector3(0.000010, 0.000000, -117.024361)), Vector3(-1.287269, -1.384040, 15.461782)), # Blender: gatilho sob o indicador da pose original (família SMG)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 10 cm da alça (uso real / CoD)
		"ads_rear": Vector3(-0.0109, 0.115, 0.149), "ads_front": Vector3(-0.0109, 0.115, 0.079), "ads_eye": 0.10,
		# boca do cano (base do silenciador embutido, separado no Blender como peça Muzzle); à frente fica a lanterna
		"muzzle_tip": Vector3(-0.011, 0.048, -0.0877),
		"one_handed": true, # segura só com a mão direita (braço esquerdo fora de cena, volta na recarga)
		# desvio lateral real do modelo: -0.0110 m (rig_fit deslocado para o gatilho real ficar sob o dedo)
		"cuts": [{"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.235), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"grip_side": "mag", # pente dentro do cabo
		"has_arms": false,
		"socket_optic": Vector3(-0.0135, 0.1267, 0.0500),
		"socket_muzzle": Vector3(-0.0135, 0.0731, -0.2871),
		"socket_mag": Vector3(-0.0135, -0.0347, -0.0220),
		"socket_underbarrel": Vector3(-0.0135, -0.0128, -0.1100),
		"socket_stock": Vector3(-0.0135, 0.0528, 0.1900),
		"socket_rear_grip": Vector3(-0.0135, -0.0500, 0.0660),
		"socket_iron_ads": Vector3(-0.0135, 0.1504, 0.1447)
	},
	"pp90m1": {
		"name": "PP90M1",
		"category": "smg",
		"scene": "res://scenes/weapons/modular/pp90m1.tscn",
		"scale": 0.45,
		"vm_scale": 0.58,
		"vm_offset": Vector3(-0.0000, 1.2000, 2.6001), # mão no cabo real (tools_capture/grip_fit, ajuste 1.3 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.075, -0.280, 0.345),
		"ads_depth": -0.36,
		"model_rotation": Vector3(180, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0044, -0.0217, -0.0952), # mão de apoio: c clamp guarda mao (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.024391, -0.000010, 0.000000), Vector3(0.000010, -117.024361, 0.000000), Vector3(0.000000, 0.000000, 117.024361)), Vector3(-0.000000, 1.143686, 6.626442)), # Blender: gatilho sob o indicador da pose original (família SMG)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 8 cm da alça (uso real / CoD)
		"ads_rear": Vector3(-0.0028, -0.0625, 0.079), "ads_front": Vector3(-0.0028, -0.0625, 0.2145), "ads_eye": 0.08, # modelo invertido: topo = y negativo
		# assento real da ótica no topo da arma (medido no Blender, espaço do glb)
		"optic_rail": Vector3(0, -0.060, 0.13),
		"optic_basis_fix": "x180",
		"cuts": [{"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, -1), "max": Vector3(1, 1, -0.08)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"has_arms": false,
		"hide_nodes": ["Icosphere"],
		"socket_optic": Vector3(-0.0032, 0.0790, 0.0000),
		"socket_muzzle": Vector3(-0.0032, 0.0545, -0.2764),
		"socket_mag": Vector3(-0.0032, -0.0400, -0.0700),
		"socket_underbarrel": Vector3(-0.0032, 0.0100, -0.1500),
		"socket_stock": Vector3(-0.0032, 0.0114, 0.2789),
		"socket_rear_grip": Vector3(-0.0032, -0.0450, 0.0500),
		"socket_iron_ads": Vector3(-0.0032, 0.0875, 0.0656)
	},
	"vmp": {
		"name": "VMP",
		"category": "smg",
		"scene": "res://scenes/weapons/modular/vmp.tscn",
		"scale": 0.46,
		"vm_scale": 0.60,
		"vm_offset": Vector3(0.0000, 1.4000, 6.8094), # mão no cabo medido no Blender (ajuste -5.0 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.075, -0.280, 0.345),
		"ads_depth": -0.36,
		"model_rotation": Vector3(0, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0055, 0.0220, -0.0114), # mão de apoio: c clamp guarda mao bullpup (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.024391, 0.000000, -0.000010), Vector3(0.000000, 117.024361, 0.000000), Vector3(0.000010, 0.000000, -117.024361)), Vector3(-0.000001, -0.564870, 17.451199)), # Blender: gatilho sob o indicador da pose original (família SMG)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 8 cm da alça (uso real / CoD)
		"ads_rear": Vector3(-0.0026, 0.115, 0.038), "ads_front": Vector3(-0.0026, 0.115, -0.062), "ads_eye": 0.08, # ponta da massa no topo da alça
		# assento real da ótica no topo da arma (medido no Blender, espaço do glb)
		"optic_rail": Vector3(0, 0.112, 0.038),
		"cuts": [{"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.215), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"has_arms": false,
		"hide_nodes": ["Cartridge", "Cube.013_Cartridge_0"],
		"socket_optic": Vector3(0, 0.0908, 0.0230),
		"socket_muzzle": Vector3(0, 0.0427, -0.2450),
		"socket_mag": Vector3(0, -0.0179, -0.0230),
		"socket_underbarrel": Vector3(0, -0.0027, -0.1150),
		"socket_stock": Vector3(0, 0.0427, 0.2000),
		"socket_rear_grip": Vector3(0, -0.0285, 0.0690),
		"socket_iron_ads": Vector3(0, 0.1405, 0.0635)
	},
	"smg": {
		"name": "SMG-45",
		"category": "smg",
		"scene": "res://scenes/weapons/modular/smg.tscn",
		"scale": 0.46,
		"vm_scale": 0.60,
		"vm_offset": Vector3(-0.0000, 1.4000, 1.0103), # mão no cabo medido no Blender (ajuste 3.7 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.075, -0.280, 0.345),
		"ads_depth": -0.36,
		"model_rotation": Vector3(-1.981, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0022, -0.0444, -0.0820), # mão de apoio: c clamp guarda mao (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.024391, 0.000000, -0.000010), Vector3(0.000000, 117.024361, 0.000000), Vector3(0.000010, 0.000000, -117.024361)), Vector3(0.912790, -1.852138, 3.560404)), # Blender: gatilho sob o indicador da pose original (família SMG)
		# punho esquerdo fecha na empunhadura vertical do modelo (medido no Blender, espaço do glb em metros)
		"support_delta": Vector3(0.015, -0.025, -0.0265),
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 10 cm da alça (uso real / CoD)
		"ads_rear": Vector3(0.0078, 0.162, 0.047), "ads_front": Vector3(0.0078, 0.162, -0.319), "ads_eye": 0.10,
		# assento real da ótica no topo da arma (medido no Blender, espaço do glb)
		"optic_rail": Vector3(0, 0.147, -0.059),
		# desvio lateral real do modelo: +0.0078 m (rig_fit deslocado para o gatilho real ficar sob o dedo)
		"cuts": [{"slot": "underbarrel", "mesh": "receiver", "min": Vector3(-1, -1, -0.30), "max": Vector3(1, 0.015, -0.235)}, {"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.1), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"has_arms": false,
		"socket_optic": Vector3(0.0062, 0.1352, -0.0200),
		"socket_muzzle": Vector3(0.0062, 0.0855, -0.2947),
		"socket_mag": Vector3(0.0062, -0.0400, -0.0800),
		"socket_underbarrel": Vector3(0.0062, 0.0200, -0.1600),
		"socket_stock": Vector3(0.0062, 0.0800, 0.2500),
		"socket_rear_grip": Vector3(0.0062, -0.0200, 0.0900),
		"socket_iron_ads": Vector3(0.0062, 0.1533, 0.0800)
	},
	"smg45": {
		"name": "SMG-45",
		"category": "smg",
		"scene": "res://scenes/weapons/modular/smg.tscn",
		"scale": 0.46,
		"vm_scale": 0.60,
		"vm_offset": Vector3(0.0, 1.4, 3.5),
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.075, -0.280, 0.345),
		"ads_depth": -0.36,
		"model_rotation": Vector3(-1.981, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"has_arms": false,
		"socket_optic": Vector3(0.0062, 0.1352, -0.0200),
		"socket_muzzle": Vector3(0.0062, 0.0855, -0.2947),
		"socket_mag": Vector3(0.0062, -0.0400, -0.0800),
		"socket_underbarrel": Vector3(0.0062, 0.0200, -0.1600),
		"socket_stock": Vector3(0.0062, 0.0800, 0.2500),
		"socket_rear_grip": Vector3(0.0062, -0.0200, 0.0900),
		"socket_iron_ads": Vector3(0.0062, 0.1533, 0.0800)
	},
	# ── ESCOPETAS ─────────────────────────────────────────────────────────────
	"spas12": {
		"name": "SPAS-12",
		"category": "shotgun",
		"scene": "res://scenes/weapons/modular/spas12.tscn",
		"scale": 0.54,
		"vm_scale": 0.84,
		"vm_offset": Vector3(0.0000, 1.8000, 7.2623), # mão no cabo real (tools_capture/grip_fit, ajuste -5.6 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.085, -0.300, 0.365),
		"ads_depth": -0.52,
		"model_rotation": Vector3(-1.556, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.1237, 0.0279, -0.0885), # mão de apoio: bomba (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.024391, 0.000002, -0.000010), Vector3(0.000000, 115.385590, 19.515818), Vector3(0.000010, 19.515818, -115.385590)), Vector3(-2.500948, -6.749563, 27.877321)), # Blender: gatilho sob o indicador da pose original (família escopeta)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho na coronha, a 30 cm da alça (uso real / CoD)
		"ads_rear": Vector3(-0.0236, 0.0918, -0.0186), "ads_front": Vector3(-0.0236, 0.0918, -0.4185), "ads_eye": 0.30,
		# assento real da ótica: topo do corpo (modelo 2,4 cm fora do centro)
		"optic_rail": Vector3(-0.0236, 0.0732, 0.09),
		"allow_optic": true, # tem trilho/topo plano: aceita ótica como no CoD
		# mão esquerda: palma sob a metade de trás da bomba (15-30 cm à frente, 4,8 cm de largura) e punho fechado em volta
		"support_point": Vector3(-0.032, 0.004, -0.26), "support_fist": 1.0, "support_hand": "pump",
		# desvio lateral real do modelo: -0.0236 m (rig_fit deslocado para o gatilho real ficar sob o dedo)
		"has_arms": false,
		"hide_nodes": ["Object_4", "Magazine"], # cartucho solto do modelo
		"socket_optic": Vector3(-0.0208, 0.0856, -0.1000),
		"socket_muzzle": Vector3(-0.0208, 0.0246, -0.4200),
		"socket_mag": Vector3(-0.0208, -0.0100, -0.0500),
		"socket_underbarrel": Vector3(-0.0208, -0.0150, -0.2000),
		"socket_stock": Vector3(-0.0208, 0.0500, 0.3500),
		"socket_rear_grip": Vector3(-0.0208, -0.0300, 0.1500),
		"socket_iron_ads": Vector3(-0.0208, 0.0878, 0.0800)
	},
	"krm262": {
		"name": "KRM-262",
		"category": "shotgun",
		"scene": "res://scenes/weapons/modular/krm262.tscn",
		"scale": 0.52,
		"vm_scale": 0.82,
		"vm_offset": Vector3(-0.0000, 1.6000, 2.3874), # mão no cabo real (tools_capture/grip_fit, ajuste 1.7 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.085, -0.300, 0.365),
		"ads_depth": -0.36,
		"model_rotation": Vector3(0, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.1061, 0.0472, -0.2489), # mão de apoio: bomba (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.024391, 0.000002, -0.000010), Vector3(0.000000, 115.385590, 19.515818), Vector3(0.000010, 19.515818, -115.385590)), Vector3(0.260830, 0.428030, 8.807804)), # Blender: gatilho sob o indicador da pose original (família escopeta)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho na coronha, a 18 cm da alça (uso real / CoD)
		"ads_rear": Vector3(0, 0.129, 0.018), "ads_front": Vector3(0, 0.129, -0.324), "ads_eye": 0.18,
		"no_barrel_visual": true, # vários tubos na boca: cano estendido só muda atributos
		# assento real da ótica: trilho alto em alça, parte traseira (medido no Blender, espaço do glb)
		"optic_rail": Vector3(0, 0.125, -0.04),
		"allow_optic": true, # tem trilho/topo plano: aceita ótica como no CoD
		# mão esquerda: palma sob a bomba (16-32 cm à frente, 5 cm de largura) e punho fechado em volta dela
		"support_point": Vector3(-0.012, 0.004, -0.24), "support_fist": 1.0, "support_hand": "pump",
		"cuts": [{"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.3), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"grip_side": "front", # bullpup: cabo à frente do pente
		"ub_max_drop": 0.25, # tubo de cartuchos fundo sob o cano
		"has_arms": false,
		"hide_nodes": ["Icosphere", "Magazine"],
		"socket_optic": Vector3(0, 0.1085, 0.0260),
		"socket_muzzle": Vector3(0, 0.0481, -0.2750),
		"socket_mag": Vector3(0, -0.0268, -0.0260),
		"socket_underbarrel": Vector3(0, -0.0081, -0.1300),
		"socket_stock": Vector3(0, 0.0481, 0.2300),
		"socket_rear_grip": Vector3(0, -0.0398, 0.0780),
		"socket_iron_ads": Vector3(0, 0.1634, 0.3688)
	},
	"shotgun": {
		"name": "Sawnoff",
		"category": "shotgun",
		"scene": "res://scenes/weapons/modular/shotgun.tscn",
		"scale": 0.44,
		"vm_scale": 0.58,
		"vm_offset": Vector3(0.0000, 1.4000, 6.8873), # mão no cabo real (tools_capture/grip_fit, ajuste -5.1 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.085, -0.300, 0.365),
		"ads_depth": -0.36,
		"model_rotation": Vector3(0, 0, 180),
		"rotation_deg": Vector3(0, 85, 3),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.1108, 0.0624, -0.0814), # mão de apoio: madeira sob canos (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(117.024391, 0.000000, 0.000000), Vector3(0.000000, -115.385590, -19.515808), Vector3(0.000000, 19.515808, -115.385590)), Vector3(0.260830, -2.564057, 25.024649)), # Blender: gatilho sob o indicador da pose original (família escopeta)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho na coronha, a 22 cm da alça (uso real / CoD)
		"ads_rear": Vector3(0, -0.075, 0.072), "ads_front": Vector3(0, -0.075, -0.302), "ads_eye": 0.22,
		"no_barrel_visual": true, # vários tubos na boca: cano estendido só muda atributos
		# mão esquerda: palma sob a telha, entre os canos (modelo invertido: palma gira 180° em torno do cano); dedos 60% pelas laterais
		"support_point": Vector3(-0.01, -0.012, -0.08), "support_fist": 0.6, "support_hand": "pump", "model_inverted": true,
		"has_arms": false,
		"socket_optic": Vector3(0, 0.0889, -0.0500),
		"socket_muzzle": Vector3(0, 0.0712, -0.2900),
		"socket_mag": Vector3(0, 0.0200, 0.0170),
		"socket_underbarrel": Vector3(0, 0.0100, -0.1500),
		"socket_stock": Vector3(0, -0.0300, 0.2500),
		"socket_rear_grip": Vector3(0, -0.0500, 0.1200),
		"socket_iron_ads": Vector3(0, 0.0889, 0.0600)
	},
	"sawnoff": {
		"name": "Sawnoff",
		"category": "shotgun",
		"scene": "res://scenes/weapons/modular/shotgun.tscn",
		"scale": 0.44,
		"vm_scale": 0.58,
		"vm_offset": Vector3(0.0, 1.4, 3.5),
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.085, -0.300, 0.365),
		"ads_depth": -0.36,
		"model_rotation": Vector3(0, 0, 180),
		"rotation_deg": Vector3(0, 85, 3),
		"y_offset": 0.02,
		# mão esquerda sob os canos, fora da linha de visada no ADS (glb invertido: +Y do Godot = para baixo na arma real)
		"has_arms": false,
		"socket_optic": Vector3(0, 0.0889, -0.0500),
		"socket_muzzle": Vector3(0, 0.0712, -0.2900),
		"socket_mag": Vector3(0, 0.0200, 0.0170),
		"socket_underbarrel": Vector3(0, 0.0100, -0.1500),
		"socket_stock": Vector3(0, -0.0300, 0.2500),
		"socket_rear_grip": Vector3(0, -0.0500, 0.1200),
		"socket_iron_ads": Vector3(0, 0.0889, 0.0600)
	},

	# ── METRALHADORAS LEVES ───────────────────────────────────────────────────
	"rpk": {
		"name": "RPK",
		"category": "lmg",
		"scene": "res://scenes/weapons/modular/rpk.tscn",
		"scale": 0.58,
		"vm_scale": 1.04,
		"vm_offset": Vector3(1.6147, -5.0873, 14.1499), # mão no cabo real (tools_capture/grip_fit, ajuste -6.2 cm)
		"vm_fit_scale": 0.9519,
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.095, -0.315, 0.370),
		"ads_depth": -0.36,
		"model_rotation": Vector3(0, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0921, 0.2056, -0.1504), # mão de apoio: c clamp guarda mao (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.023415, -0.477971, -0.000010), Vector3(-0.477971, 117.023384, 0.000000), Vector3(0.000010, 0.000000, -117.024361)), Vector3(0.071694, -14.195594, 26.967350)), # Blender: gatilho sob o indicador da pose original (família AK — usada pela LMG e pelo RPK no jogo)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 9 cm da alça (uso real / CoD)
		"ads_rear": Vector3(0, 0.285, 0.22), "ads_front": Vector3(0, 0.285, -0.349), "ads_eye": 0.09,
		"cuts": [{"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.3), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"has_arms": false,
		"hide_nodes": [
			"545_20", "casing_545_17", "Object_44", "Object_45",
			"Object_52", "Object_53", "Object_54"
		],
		"socket_optic": Vector3(0.0, 0.3059, 0.1000), # topo real do receptor (antes ficava dentro do corpo)
		"socket_muzzle": Vector3(0, 0.0473, -0.3050),
		"socket_mag": Vector3(0, -0.0255, -0.0290),
		"socket_underbarrel": Vector3(0, -0.0073, -0.1450),
		"socket_stock": Vector3(0, 0.0473, 0.2600),
		"socket_rear_grip": Vector3(0, -0.0383, 0.0870),
		"socket_iron_ads": Vector3(0.0, 0.3099, 0.1560) # topo do modelo, 35% a partir da traseira
	},
	"lmg": {
		"name": "LMG-63",
		"category": "lmg",
		"scene": "res://scenes/weapons/modular/lmg.tscn",
		"scale": 0.58,
		"vm_scale": 0.95,
		"vm_offset": Vector3(0.0000, 1.8000, 4.2096), # mão no cabo real (tools_capture/grip_fit, ajuste -1.1 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.095, -0.315, 0.370),
		"ads_depth": -0.36,
		"model_rotation": Vector3(-0.729, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"grip_l": Vector3(-0.0825, -0.0701, -0.0655), # mão de apoio: empunhadura embutida (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.023415, -0.477971, -0.000010), Vector3(-0.477971, 117.023384, 0.000000), Vector3(0.000010, 0.000000, -117.024361)), Vector3(-0.014197, 6.833509, 22.824688)), # Blender: gatilho sob o indicador da pose original (família AK — usada pela LMG e pelo RPK no jogo)
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 9 cm da alça (uso real / CoD)
		"ads_rear": Vector3(0.0023, 0.129, 0.245), "ads_front": Vector3(0.0023, 0.129, -0.376), "ads_eye": 0.09,
		# mão esquerda: punho fechado no terço superior da empunhadura vertical embutida (topo -7,4 cm, 18,6 cm à frente)
		"support_point": Vector3(-0.023, -0.104, -0.186), "support_fist": 1.0,
		"cuts": [{"slot": "underbarrel", "mesh": "receiver", "min": Vector3(-1, -1, -0.215), "max": Vector3(1, -0.02, -0.15)}, {"slot": "stock", "mesh": "receiver", "min": Vector3(-1, -1, 0.29), "max": Vector3(1, 1, 1)}], # coronha fundida no corpo: recortada quando entra coronha tática
		"has_arms": false,
		"socket_optic": Vector3(0.0021, 0.1030, 0.0000),
		"socket_muzzle": Vector3(0.0021, 0.0733, -0.5000),
		"socket_mag": Vector3(-0.0400, 0.0000, 0.0200),
		"socket_underbarrel": Vector3(0.0021, 0.0200, -0.2000),
		"socket_stock": Vector3(0.0021, 0.0800, 0.4500),
		"socket_rear_grip": Vector3(0.0021, -0.0400, 0.1500),
		"socket_iron_ads": Vector3(0.0021, 0.1432, 0.1800)
	},
	"lmg63": {
		"name": "LMG-63",
		"category": "lmg",
		"scene": "res://scenes/weapons/modular/lmg.tscn",
		"scale": 0.58,
		"vm_scale": 0.95,
		"vm_offset": Vector3(0.0, 1.8, 3.5),
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.095, -0.315, 0.370),
		"ads_depth": -0.36,
		"model_rotation": Vector3(-0.729, 0, 0),
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"has_arms": false,
		"socket_optic": Vector3(0.0021, 0.1030, 0.0000),
		"socket_muzzle": Vector3(0.0021, 0.0733, -0.5000),
		"socket_mag": Vector3(-0.0400, 0.0000, 0.0200),
		"socket_underbarrel": Vector3(0.0021, 0.0200, -0.2000),
		"socket_stock": Vector3(0.0021, 0.0800, 0.4500),
		"socket_rear_grip": Vector3(0.0021, -0.0400, 0.1500),
		"socket_iron_ads": Vector3(0.0021, 0.1432, 0.1800)
	},

	# ── FUZIS DE PRECISÃO (SNIPERS) ───────────────────────────────────────────
	# (Locus e DSR-50 removidos - aguardando inclusão da nova sniper)


	# ── SECUNDÁRIAS, PISTOLAS & CORPO A CORPO ─────────────────────────────────
	"deagle": {
		"name": ".50 GS Deagle",
		"category": "secondary",
		"scene": "res://scenes/weapons/modular/deagle.tscn",
		"scale": 0.38,
		"vm_scale": 0.28,
		"vm_offset": Vector3(0.0000, 0.5000, 2.5718), # mão no cabo real (tools_capture/grip_fit, ajuste -1.6 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.060, -0.250, 0.320),
		"ads_depth": -0.34,
		"model_rotation": Vector3(0, 0, 0),
		"rotation_deg": Vector3(0, 85, 4),
		"y_offset": 0.015,
		"grip_l": Vector3(0.0505, -0.0514, 0.1981), # mão de apoio: pistola duas maos (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.012665, 1.656164, -0.035717), Vector3(1.652361, 116.869003, 5.797137), Vector3(0.117712, 5.796052, -116.880684)), Vector3(-0.012974, 1.051537, 9.667155)), # Blender: gatilho sob o indicador da pose original (família pistola)
		# duas mãos (padrão CoD): palma esquerda no lado esquerdo do cabo, espelhando a direita, 2 cm abaixo (espaço do glb)
		"support_point": Vector3(-0.044, -0.0592, 0.0989),
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 28 cm da alça (uso real / CoD)
		"ads_rear": Vector3(0, 0.0745, 0.0825), "ads_front": Vector3(0, 0.0745, -0.126), "ads_eye": 0.28,
		"has_arms": false,
		"hide_nodes": ["Bullet_low", "BulletCase_low", "BulletThrow_low"],
		"socket_optic": Vector3(0, 0.1181, 0.0190),
		"socket_muzzle": Vector3(0, 0.0474, -0.2050),
		"socket_mag": Vector3(0, -0.0391, -0.0190),
		"socket_underbarrel": Vector3(0, -0.0174, -0.0950),
		"socket_stock": Vector3(0, 0.0474, 0.1600),
		"socket_rear_grip": Vector3(0, -0.0542, 0.0570),
		"socket_iron_ads": Vector3(0, 0.0905, 0.0880)
	},
	"pistol": {
		"name": "Pistola C19",
		"category": "secondary",
		"scene": "res://scenes/weapons/modular/pistol.tscn",
		"scale": 0.34,
		"vm_scale": 0.28,
		"vm_offset": Vector3(0.0000, 0.5000, 1.8909), # mão no cabo medido no Blender (ajuste -0.6 cm)
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.060, -0.250, 0.320),
		"ads_depth": -0.34,
		"model_rotation": Vector3(-2.764, 0, 0),
		"rotation_deg": Vector3(0, 85, 4),
		"y_offset": 0.015,
		"grip_l": Vector3(0.0505, -0.0513, 0.1880), # mão de apoio: pistola duas maos (tools_capture/support_fit, palma medida após o IK)
		"rig_fit": Transform3D(Basis(Vector3(-117.012665, 1.656164, -0.035717), Vector3(1.652361, 116.869003, 5.797137), Vector3(0.117712, 5.796052, -116.880684)), Vector3(-0.054872, -1.902740, 9.942418)), # Blender: gatilho sob o indicador da pose original (família pistola)
		# duas mãos (padrão CoD): palma esquerda no lado esquerdo do cabo, espelhando a direita, 2 cm abaixo (espaço do glb)
		"support_point": Vector3(-0.044, -0.0341, 0.1025),
		# mira de ferro medida no modelo (Blender): alça e massa no espaço do glb; olho a 28 cm da alça (uso real / CoD)
		"ads_rear": Vector3(0.0011, 0.099, 0.181), "ads_front": Vector3(0.0011, 0.108, -0.0396), "ads_eye": 0.28,
		"has_arms": false,
		"socket_optic": Vector3(0.0020, 0.0850, -0.0200),
		"socket_muzzle": Vector3(0.0020, 0.0550, -0.1950),
		"socket_mag": Vector3(0.0020, -0.0300, 0.0900),
		"socket_underbarrel": Vector3(0.0020, -0.0100, -0.0800),
		"socket_stock": Vector3(0.0020, 0.0100, 0.1700),
		"socket_rear_grip": Vector3(0.0020, -0.0400, 0.0600),
		"socket_iron_ads": Vector3(0.0020, 0.0845, 0.0800)
	},
	"c19": {
		"name": "Pistola C19",
		"category": "secondary",
		"scene": "res://scenes/weapons/modular/pistol.tscn",
		"scale": 0.34,
		"vm_scale": 0.28,
		"vm_offset": Vector3(0.0, 0.5, 1.5),
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.060, -0.250, 0.320),
		"ads_depth": -0.34,
		"model_rotation": Vector3(-2.764, 0, 0),
		"rotation_deg": Vector3(0, 85, 4),
		"y_offset": 0.015,
		"has_arms": false,
		"socket_optic": Vector3(0.0020, 0.0850, -0.0200),
		"socket_muzzle": Vector3(0.0020, 0.0550, -0.1950),
		"socket_mag": Vector3(0.0020, -0.0300, 0.0900),
		"socket_underbarrel": Vector3(0.0020, -0.0100, -0.0800),
		"socket_stock": Vector3(0.0020, 0.0100, 0.1700),
		"socket_rear_grip": Vector3(0.0020, -0.0400, 0.0600),
		"socket_iron_ads": Vector3(0.0020, 0.0845, 0.0800)
	},
	"knife": {
		"name": "Combat Knife",
		"category": "secondary",
		"scene": "res://scenes/weapons/modular/knife.tscn",
		"scale": 0.34,
		"vm_scale": 0.30,
		"vm_offset": Vector3.ZERO,
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.055, -0.220, 0.300),
		"ads_depth": -0.30,
		"model_rotation": Vector3(0, 90, 0),
		"rotation_deg": Vector3(0, 85, 4),
		"y_offset": 0.015,
		"has_arms": true,
		"socket_optic": Vector3.ZERO,
		"socket_muzzle": Vector3.ZERO,
		"socket_mag": Vector3.ZERO,
		"socket_underbarrel": Vector3.ZERO,
		"socket_stock": Vector3.ZERO,
		"socket_rear_grip": Vector3.ZERO,
		"socket_iron_ads": Vector3.ZERO
	}
}

# Cenas de acessórios 3D
# ── COMPATIBILIDADE DE ACESSÓRIOS ─────────────────────────────────────────────
# Quais encaixes cada arma aceita, pela categoria. A mira óptica também exige has_optic
# no WeaponData (armas cujo ADS com luneta ainda não foi validado ficam só com mira de ferro).
const SLOTS_BY_CATEGORY := {
	"ar": ["optic", "muzzle", "barrel", "mag", "underbarrel", "stock", "grip"],
	"lmg": ["optic", "muzzle", "barrel", "mag", "underbarrel", "stock", "grip"],
	"smg": ["optic", "muzzle", "barrel", "mag", "underbarrel", "stock", "grip"],
	"shotgun": ["optic", "muzzle", "barrel", "underbarrel", "stock", "grip"],
	"secondary": ["optic", "muzzle", "mag"],
}

static func get_allowed_slots(weapon_path_or_id: String) -> Array:
	var cfg = get_weapon_config(weapon_path_or_id)
	var slots: Array = SLOTS_BY_CATEGORY.get(cfg.get("category", ""), []).duplicate()
	if "optic" in slots:
		var wid := weapon_path_or_id.get_file().get_basename()
		var res_path := "res://resources/weapons/%s.tres" % wid
		if ResourceLoader.exists(res_path):
			var data = load(res_path)
			# arma sem ótica de fábrica não recebe ótica, salvo liberação explícita (trilho real, ex.: KRM-262, SPAS-12)
			if data and "has_optic" in data and not data.has_optic and not bool(cfg.get("allow_optic", false)):
				slots.erase("optic")
	return slots

static func is_slot_allowed(weapon_path_or_id: String, slot: String) -> bool:
	return slot in get_allowed_slots(weapon_path_or_id)

const ATTACHMENT_SCENES: Dictionary = {
	"optic_red_dot": "res://scenes/weapons/attachments/optic_red_dot.tscn",
	"red_dot": "res://scenes/weapons/attachments/optic_red_dot.tscn",
	"optic_holo": "res://scenes/weapons/attachments/optic_holo.tscn",
	"holo": "res://scenes/weapons/attachments/optic_holo.tscn",
	"optic_acog": "res://scenes/weapons/attachments/optic_acog.tscn",
	"acog": "res://scenes/weapons/attachments/optic_acog.tscn",
	"optic_sniper": "res://scenes/weapons/attachments/optic_sniper.tscn",
	"sniper": "res://scenes/weapons/attachments/optic_sniper.tscn",
	"silencer": "res://scenes/weapons/attachments/muzzle_silencer.tscn",
	"muzzle_suppressor": "res://scenes/weapons/attachments/muzzle_silencer.tscn",
	"compensator": "res://scenes/weapons/attachments/muzzle_compensator.tscn",
	"muzzle_compensator": "res://scenes/weapons/attachments/muzzle_compensator.tscn",
	"extended": "res://scenes/weapons/attachments/mag_extended.tscn",
	"mag_extended": "res://scenes/weapons/attachments/mag_extended.tscn",
	"fast": "res://scenes/weapons/attachments/mag_fast.tscn",
	"mag_fast": "res://scenes/weapons/attachments/mag_fast.tscn",
	"fast_mag": "res://scenes/weapons/attachments/mag_fast.tscn",
	"grip_vertical": "res://scenes/weapons/attachments/grip_vertical.tscn",
	"vertical_grip": "res://scenes/weapons/attachments/grip_vertical.tscn",
	"grip_angled": "res://scenes/weapons/attachments/grip_angled.tscn",
	"angled_grip": "res://scenes/weapons/attachments/grip_angled.tscn",
	"stock_light": "res://scenes/weapons/attachments/stock_light.tscn",
	"stock_heavy": "res://scenes/weapons/attachments/stock_heavy.tscn",
	"grip_rubber": "res://scenes/weapons/attachments/grip_rear.tscn",
	"grip_stippled": "res://scenes/weapons/attachments/grip_rear.tscn"
}

# Mapeamento explícito de apelidos e identificadores para chaves primárias do registro
const ALIASES: Dictionary = {
	"acr68": "acr68",
	"acr": "acr68",
	"ak47": "acr68",
	"ak": "acr68",
	"ak-47": "acr68",
	"m4": "m4a1",
	"m4-a1": "m4a1",
	"sawnoff": "shotgun",
	"c19": "pistol",
	"pistol_m9": "pistol",
	"m9": "pistol",
	"smg45": "smg",
	"mp-7": "mp7",
	"lmg63": "lmg",
	"scarh": "scar_h",
	"scar": "scar_h",
	"manowar": "man_o_war",
	"spas": "spas12",
	"spas-12": "spas12",
	"krm": "krm262",
	"krm-262": "krm262",
	"pp90": "pp90m1",
	"pp-90m1": "pp90m1",
	"pp19": "pp90m1",
	"bizon": "pp90m1",
	"desert_eagle": "deagle",
	"deserteagle": "deagle",
	"faca": "knife"
}

# ── OBTENÇÃO DA CONFIGURAÇÃO DA ARMA ──────────────────────────────────────────
static func get_weapon_config(weapon_path_or_id: String) -> Dictionary:
	var key = _extract_key(weapon_path_or_id)
	if REGISTRY.has(key):
		return REGISTRY[key]
	
	# Fallback inteligente por categoria somente se houver correspondência exata de chave
	var p_low = weapon_path_or_id.to_lower()
	for k in REGISTRY.keys():
		if k == p_low or p_low.ends_with("/" + k) or p_low.ends_with("/" + k + ".tres"):
			return REGISTRY[k]

	# Fallback geral neutro isolado (NUNCA retorna REGISTRY["acr68"] para não contaminar outras armas)
	push_warning("[WeaponVisualRegistry] Arma '%s' não encontrada no registro! Usando configuração neutra isolada." % weapon_path_or_id)
	return {
		"name": "Arma Desconhecida",
		"category": "ar",
		"scene": "",
		"scale": 0.52,
		"vm_scale": 1.0,
		"vm_offset": Vector3.ZERO,
		"vm_rotation": Vector3.ZERO,
		"hip_offset": Vector3(-0.092, -0.315, 0.360),
		"ads_depth": -0.36,
		"model_rotation": Vector3.ZERO,
		"rotation_deg": Vector3(0, 80, 4),
		"y_offset": 0.02,
		"has_arms": false,
		"socket_optic": Vector3.ZERO,
		"socket_muzzle": Vector3.ZERO,
		"socket_mag": Vector3.ZERO,
		"socket_underbarrel": Vector3.ZERO,
		"socket_stock": Vector3.ZERO,
		"socket_rear_grip": Vector3.ZERO,
		"socket_iron_ads": Vector3.ZERO
	}

static func _extract_key(weapon_path_or_id: String) -> String:
	var clean = weapon_path_or_id.to_lower().strip_edges()
	clean = clean.replace(".tres", "").replace("res://resources/weapons/", "")
	
	# Verificar apelidos diretos primeiro
	if ALIASES.has(clean):
		return ALIASES[clean]
	
	if REGISTRY.has(clean):
		return clean
		
	var clean_no_underscores = clean.replace("_", "").replace("-", "")
	if ALIASES.has(clean_no_underscores):
		return ALIASES[clean_no_underscores]

	for k in REGISTRY.keys():
		var k_clean = k.replace("_", "").replace("-", "")
		if clean_no_underscores == k or clean_no_underscores == k_clean:
			return k
	return clean

# ── INSTANCIAÇÃO DA ARMA PARA VIEWMODEL DE 1ª PESSOA NAS MÃOS ─────────────────
static func instantiate_weapon_for_hand(weapon_path_or_id: String) -> Node3D:
	var cfg = get_weapon_config(weapon_path_or_id)
	var scene_path = cfg["scene"]
	if not ResourceLoader.exists(scene_path):
		return null

	var sc = load(scene_path) as PackedScene
	if not sc:
		return null

	var inst = sc.instantiate() as Node3D
	if not inst:
		return null

	# Aplicar rotação nativa do modelo para orientação canônica (frente = -Z)
	if cfg.has("model_rotation"):
		inst.rotation_degrees = cfg["model_rotation"]

	# Ocultar braços se existirem na malha
	if cfg.get("has_arms", false):
		_clean_arms_recursive(inst)

	# Ocultar nós indesejados da malha (ex: cartuchos avulsos como Object_4, 545_20)
	for n_name in cfg.get("hide_nodes", []):
		for n in inst.find_children("*" + n_name + "*", "", true, false):
			if n is Node3D or n is CanvasItem:
				n.visible = false
				n.set_meta("force_hidden", true)

	_cache_base_materials_recursive(inst)

	var wrapper = Node3D.new()
	wrapper.name = "CustomWeaponModel"
	wrapper.set_meta("config", cfg)

	var pivot = Node3D.new()
	pivot.name = "Pivot"
	wrapper.add_child(pivot)
	pivot.add_child(inst)

	# Centralizar e calibrar a arma para escala real de 1ª pessoa nas mãos
	var aabb = _calc_visible_mesh_aabb(inst)
	var longest = aabb.get_longest_axis_size()
	var target_scale = cfg.get("vm_scale", cfg.get("scale", 0.52))
	var scale_mult = target_scale / max(longest, 0.001)

	inst.scale = Vector3.ONE * scale_mult
	inst.position = -aabb.get_center() * scale_mult
	inst.position.y += cfg.get("y_offset", 0.02)

	# Na hierarquia do Bytez fps-ak/fps-hands, o eixo Z local do nó 'base' aponta para frente (+Z).
	# Os modelos clean têm frente canônica em -Z, então rotacionamos 180° no eixo Y para apontar para +Z.
	var rot_y = cfg.get("vm_rot_y", 180.0)
	pivot.rotation_degrees = Vector3(0, rot_y, 0)
	if cfg.has("vm_rotation"):
		pivot.rotation_degrees += cfg["vm_rotation"]

	return wrapper

# ── INSTANCIAÇÃO DA ARMA COM LIMPEZA DE BRAÇOS E CENTRALIZAÇÃO ────────────────
static func instantiate_weapon_showcase(weapon_path_or_id: String) -> Node3D:
	var cfg = get_weapon_config(weapon_path_or_id)
	var scene_path = cfg["scene"]
	
	if not ResourceLoader.exists(scene_path):
		scene_path = "res://assets/models/fps_hands_rifle/scene.gltf"

	var sc = load(scene_path) as PackedScene
	if not sc:
		return null

	var inst = sc.instantiate() as Node3D
	if not inst:
		return null

	# Aplicar rotação nativa do modelo para orientação canônica (frente = -Z)
	if cfg.has("model_rotation"):
		inst.rotation_degrees = cfg["model_rotation"]

	# Ocultar malhas de braços se o modelo for do pack fps-hands
	if cfg.get("has_arms", false):
		_clean_arms_recursive(inst)

	# Ocultar nós indesejados da malha (ex: cartuchos avulsos como Object_4, 545_20)
	for n_name in cfg.get("hide_nodes", []):
		for n in inst.find_children("*" + n_name + "*", "", true, false):
			if n is Node3D or n is CanvasItem:
				n.visible = false
				n.set_meta("force_hidden", true)

	# Fazer cache de materiais originais para que o camo default nunca apague
	_cache_base_materials_recursive(inst)

	# Container raiz padronizado
	var wrapper = Node3D.new()
	wrapper.name = "ShowcaseWeaponRoot"
	wrapper.set_meta("config", cfg)
	# a vitrine reduz a arma para caber na tela; os acessórios acompanham a mesma redução
	wrapper.set_meta("attachment_scale", float(cfg.get("scale", 0.52)) / float(cfg.get("vm_scale", cfg.get("scale", 0.52))))

	var pivot = Node3D.new()
	pivot.name = "Pivot"
	wrapper.add_child(pivot)
	pivot.add_child(inst)

	# Calcular AABB composto considerando transform inicial e centralizar
	var aabb = _calc_visible_mesh_aabb(inst)
	var longest = aabb.get_longest_axis_size()
	var target_scale = cfg.get("scale", 0.52)
	var scale_mult = target_scale / max(longest, 0.001)

	inst.scale = Vector3.ONE * scale_mult
	inst.position = -aabb.get_center() * scale_mult
	inst.position.y += cfg.get("y_offset", 0.02)

	# Aplicar orientação base de apresentação tática
	var rot_deg = cfg.get("rotation_deg", Vector3(0, 80, 4))
	pivot.rotation_degrees = rot_deg

	return wrapper

# ── ATUALIZAÇÃO MODULAR DE ACESSÓRIOS GUNSMITH EM TEMPO REAL ──────────────────
static func update_attachments(
	wrapper: Node3D,
	optic_id: String = "none",
	muzzle_id: String = "none",
	mag_id: String = "none",
	underbarrel_id: String = "none",
	stock_id: String = "none",
	grip_id: String = "none",
	barrel_id: String = "none"
) -> void:
	if not wrapper:
		return

	var cfg = wrapper.get_meta("config", {})
	if cfg.is_empty():
		return

	var pivot = wrapper.get_node_or_null("Pivot")
	if not pivot:
		return

	# Buscar a instância da arma dentro do Pivot (ou usar o pivot diretamente como fallback)
	var inst: Node3D = null
	for child in pivot.get_children():
		if child is Node3D and child.name != "AttachmentContainer":
			inst = child
			break
	var target_parent: Node3D = inst if inst else pivot

	# MONTADOR ÚNICO (arma na mão, Gunsmith e seleção usam este mesmo código):
	# acessórios ficam no Pivot (em metros, escala 1); a posição de cada encaixe vem do marcador
	# do modelo (SocketX) convertido para o espaço do Pivot, ou do registro quando não há marcador.
	var att_container = pivot.get_node_or_null("AttachmentContainer")
	var old_container = target_parent.get_node_or_null("AttachmentContainer") if target_parent != pivot else null
	if old_container:
		old_container.free()
	if not att_container:
		att_container = Node3D.new()
		att_container.name = "AttachmentContainer"
		pivot.add_child(att_container)
	else:
		for c in att_container.get_children():
			c.free()

	var slots := [
		["optic", optic_id, "SocketOptic", "socket_optic", Vector3(0, 0.12, 0)],
		["muzzle", muzzle_id, "SocketMuzzle", "socket_muzzle", Vector3(0, 0.02, -0.28)],
		["mag", mag_id, "SocketMag", "socket_mag", Vector3(0, -0.12, 0)],
		["underbarrel", underbarrel_id, "SocketUnderbarrel", "socket_underbarrel", Vector3(0, -0.06, -0.12)],
		["stock", stock_id, "SocketStock", "socket_stock", Vector3(0, 0.06, 0.22)],
		["grip", grip_id, "SocketRearGrip", "socket_rear_grip", Vector3(0, -0.10, 0.05)],
	]
	var allowed: Array = SLOTS_BY_CATEGORY.get(cfg.get("category", ""), ["optic", "muzzle", "mag", "underbarrel", "stock", "grip"])
	for sl in slots:
		var att_id: String = sl[1]
		if att_id == "none" or att_id == "" or att_id == "optic_iron" or not ATTACHMENT_SCENES.has(att_id):
			continue
		if not (sl[0] in allowed):
			continue  # encaixe que essa categoria de arma não tem (ex.: pente em escopeta de tubo)
		var att_scale: float = wrapper.get_meta("attachment_scale", 1.0)
		var fallback: Vector3 = cfg.get(sl[3], sl[4]) * att_scale
		var pos := _socket_in_pivot(pivot, target_parent, sl[2], fallback)
		var node := _spawn_attachment(att_container, ATTACHMENT_SCENES[att_id], pos, att_scale)
		if node:
			_decorate_attachment(node, att_id)
			node.name = "Att_" + String(sl[0])
			node.set_meta("slot", sl[0])
			node.set_meta("attachment_id", att_id)

	# Cano estendido: peça gerada por código no encaixe (diâmetro real da ponta do cano de cada arma)
	# (escopetas de dois canos / cano + tubo: não há um cano único para prolongar -> só atributos)
	if barrel_id == "barrel_extended" and "barrel" in allowed and not bool(cfg.get("no_barrel_visual", false)):
		var bnode := Node3D.new()
		bnode.name = "Att_barrel"
		bnode.set_meta("slot", "barrel")
		bnode.set_meta("attachment_id", barrel_id)
		att_container.add_child(bnode)
	# Cano curto: sem o quebra-chamas do modelo (quando ele é uma peça separada), como num cano cortado
	var muzzle_for_parts := muzzle_id
	if barrel_id == "barrel_short" and "barrel" in allowed and (muzzle_id == "none" or muzzle_id == ""):
		muzzle_for_parts = "barrel_short"
	# Controle dinâmico unificado: Ocultar peças nativas (miras, magazine, coronha, boca, cabo) quando substituídas
	update_integrated_weapon_parts(target_parent, optic_id, muzzle_for_parts, mag_id, underbarrel_id, stock_id, grip_id)
	# Peças fundidas na malha do corpo (coronha, cabo, empunhadura): recorta a região quando o acessório entra
	var active := []
	for pair in [["stock", stock_id], ["grip", grip_id], ["underbarrel", underbarrel_id]]:
		if pair[1] != "none" and pair[1] != "" and pair[0] in allowed:
			active.append(pair[0])
	_apply_body_cuts(pivot, cfg, active)
	# Encaixe pela geometria real (depois de esconder as peças originais)
	_snap_attachments(pivot, att_container, cfg)

# ── CONTROLE DINÂMICO UNIFICADO DE PEÇAS ORIGINAIS DA ARMA ────────────────────
static func update_integrated_weapon_parts(
	root: Node3D,
	optic_id: String,
	muzzle_id: String,
	mag_id: String = "none",
	underbarrel_id: String = "none",
	stock_id: String = "none",
	grip_id: String = "none"
) -> void:
	if not root:
		return

	var has_optic = (optic_id != "none" and optic_id != "" and optic_id != "optic_iron")
	var has_muzzle = (muzzle_id != "none" and muzzle_id != "")
	var has_mag = (mag_id != "none" and mag_id != "")
	var has_underbarrel = (underbarrel_id != "none" and underbarrel_id != "")
	var has_stock = (stock_id != "none" and stock_id != "")
	var has_grip = (grip_id != "none" and grip_id != "")

	# Padrões de miras de ferro, lunetas e alças de mira nativas a ocultar quando optic != none
	var sight_patterns = [
		"rear sight", "rear_sight", "rearsight", "sight_base", "sight base", "sight_cam",
		"sight cam", "windage", "sight_eotech", "eotech", "rifle_scope",
		"integratedscope", "heavyscope", "object_14", "carryhandle", "ironsight",
		"front sight", "front_sight", "object_2", "object_24"
	]

	# Padrões de quebra-chamas, compensadores e silenciadores nativos a ocultar quando muzzle != none
	var muzzle_patterns = [
		"muzzle_brake", "compensator__0", "crush washer", "rifle_silencer",
		"flashlight", "object_13", "object_59", "muzzlebreak_mat_0"
	]

	# Padrões de carregadores nativos a ocultar quando um novo magazine for equipado
	var mag_patterns = [
		"clip_smg45_0", "magazine_acr", "magazine box__0", "mag_scar", "rifle_mag",
		"cube.013_cartridge_0", "magazine_low", "mag_lmg", "clip_mat_0",
		"magazine bottom plate__0", "magazine follower__0", "magazine spring__0",
		"object_56", "object_57", "object_32", "object_34", "object_18", "object_5"
	]

	# Padrões de coronhas nativas a ocultar quando coronha tática for equipada
	var stock_patterns = [
		"sliding buttstock__0", "buttstock release lever", "buttstock spring pin",
		"lock pin nut", "sliding buttstock", "buttstock", "object_8", "stock_2"
	]

	# Padrões de foregrips nativos a ocultar quando underbarrel for equipado
	var underbarrel_patterns = [
		"vertical pistol grip__0", "vertical pistol grip lock", "polysurface82_handle_mat_0"
	]

	# Padrões de grips traseiros nativos a ocultar quando rear grip for equipado
	var grip_patterns = [
		"pistol grip__0", "grip_low_mainbody_0", "object_33", "object_34"
	]

	for child in root.find_children("*", "Node3D", true, false):
		if child.has_meta("force_hidden"):
			child.visible = false
			continue
		# 0. Peças nomeadas dos modelos modulares (Magazine, Stock, Muzzle, Sight, Front_Sight, Rear_Sight, RearGrip)
		var mod_name := String(child.name).to_lower().get_slice(".", 0)
		if mod_name == "magazine" or mod_name.begins_with("magazine_"):
			child.visible = not has_mag
			continue
		if mod_name == "stock":
			child.visible = not has_stock
			continue
		if mod_name == "muzzle":
			child.visible = not has_muzzle
			continue
		if mod_name in ["sight", "front_sight", "rear_sight"]:
			child.visible = not has_optic
			continue
		if mod_name == "reargrip":
			child.visible = not has_grip
			continue
		# 1. Checagem direta de nós modulares estruturados
		if child.has_meta("part_type"):
			var p_type = child.get_meta("part_type")
			match p_type:
				"magazine":
					child.visible = not has_mag
					continue
				"stock":
					child.visible = not has_stock
					continue
				"sight":
					child.visible = not has_optic
					continue
				"muzzle":
					child.visible = not has_muzzle
					continue
				"underbarrel":
					child.visible = not has_underbarrel
					continue
				"rear_grip":
					child.visible = not has_grip
					continue

		var c_name = child.name
		if c_name == "Magazine":
			child.visible = not has_mag
			continue
		elif c_name == "Stock":
			child.visible = not has_stock
			continue
		elif c_name == "Sight":
			child.visible = not has_optic
			continue
		elif c_name == "Muzzle":
			child.visible = not has_muzzle
			continue
		elif c_name == "Underbarrel":
			child.visible = not has_underbarrel
			continue
		elif c_name == "RearGrip":
			child.visible = not has_grip
			continue

		# 2. Fallback inteligente recursivo por substrings
		var n_low = c_name.to_lower()
		
		# Miras
		for pat in sight_patterns:
			if pat in n_low:
				child.visible = not has_optic
				break

		# Bocas
		for pat in muzzle_patterns:
			if pat in n_low:
				child.visible = not has_muzzle
				break

		# Carregadores
		for pat in mag_patterns:
			if pat in n_low:
				child.visible = not has_mag
				break

		# Coronhas
		for pat in stock_patterns:
			if pat in n_low:
				child.visible = not has_stock
				break

		# Foregrips
		for pat in underbarrel_patterns:
			if pat in n_low:
				child.visible = not has_underbarrel
				break

		# Rear grips
		for pat in grip_patterns:
			if pat in n_low:
				child.visible = not has_grip
				break

# Alias de compatibilidade retroativa
static func update_integrated_sights_and_muzzle(root: Node3D, optic_id: String, muzzle_id: String) -> void:
	update_integrated_weapon_parts(root, optic_id, muzzle_id)

## Posição de um marcador de encaixe do modelo no espaço do Pivot (funciona fora da árvore de cena)
static func _socket_in_pivot(pivot: Node3D, model_root: Node3D, socket_name: String, fallback_pos: Vector3) -> Vector3:
	var marker = model_root.find_child(socket_name, true, false) as Node3D
	if not marker:
		return fallback_pos
	var xf := Transform3D.IDENTITY
	var n: Node = marker
	while n and n != pivot:
		if n is Node3D:
			xf = (n as Node3D).transform * xf
		n = n.get_parent()
	return xf.origin

static func _find_or_get_socket(root: Node3D, socket_name: String, fallback_pos: Vector3) -> Vector3:
	var marker = root.find_child(socket_name, true, false) as Marker3D
	if marker:
		return marker.position
	return fallback_pos

static func _spawn_attachment(parent: Node3D, scene_path: String, pos: Vector3, att_scale: float = 1.0) -> Node3D:
	if not ResourceLoader.exists(scene_path):
		return null
	var sc = load(scene_path) as PackedScene
	if not sc:
		return null
	var inst = sc.instantiate() as Node3D
	if inst:
		inst.position = pos
		inst.scale = Vector3.ONE * att_scale
		parent.add_child(inst)
	return inst

# ── ENCAIXE PELA GEOMETRIA ─────────────────────────────────────────────────────
# Os pontos de encaixe foram marcados com as peças originais no lugar; quando a coronha,
# o cano ou o pente originais são escondidos, o acessório ficava solto. Aqui cada acessório
# é encostado na geometria visível da arma (espaço do Pivot).
static func _visible_in(node: Node, stop: Node) -> bool:
	var n: Node = node
	while n and n != stop:
		if n is Node3D and not (n as Node3D).visible:
			return false
		n = n.get_parent()
	return true

static func _xf_to(node: Node3D, root: Node3D) -> Transform3D:
	var xf := Transform3D.IDENTITY
	var n: Node = node
	while n and n != root:
		if n is Node3D:
			xf = (n as Node3D).transform * xf
		n = n.get_parent()
	return xf

## Assenta uma mira (luneta, red dot) no topo real da arma, onde ela fica ao longo do cano
static func snap_optic_to_rail(pivot: Node3D, optic: Node3D) -> void:
	if not pivot or not optic:
		return
	var ob := AABB(); var first := true
	for m in optic.find_children("*", "MeshInstance3D", true, false):
		if m.mesh == null: continue
		var b: AABB = _xf_to(m, pivot) * m.get_aabb()
		ob = b if first else ob.merge(b); first = false
	if first:
		return
	# altura do trilho: máximo por fatia de 0,5 cm ao longo da mira, e a MEDIANA dessas fatias
	# (postes de mira de ferro e peças finas e altas ocupam poucas fatias e são ignorados)
	var step := 0.005
	var nb := maxi(1, int(ceil(ob.size.z / step)))
	var bins := []
	bins.resize(nb)
	bins.fill(-INF)
	for m in pivot.find_children("*", "MeshInstance3D", true, false):
		if optic.is_ancestor_of(m) or m.mesh == null or not _visible_in(m, pivot) or m.layers == 0:
			continue
		if m.get_parent() and String(m.get_parent().name) == "AttachmentContainer":
			continue
		var xf := _xf_to(m, pivot)
		for sidx in m.mesh.get_surface_count():
			for v in m.mesh.surface_get_arrays(sidx)[Mesh.ARRAY_VERTEX]:
				var p: Vector3 = xf * v
				if p.z >= ob.position.z and p.z < ob.end.z and absf(p.x - ob.get_center().x) < 0.03:
					var b := clampi(int((p.z - ob.position.z) / step), 0, nb - 1)
					if p.y > bins[b]:
						bins[b] = p.y
	var filled := bins.filter(func(x): return x != -INF)
	if filled.size() > 0:
		filled.sort()
		var rail: float = filled[filled.size() / 2]
		optic.position.y += rail - ob.position.y

static func _snap_attachments(pivot: Node3D, cont: Node3D, cfg: Dictionary) -> void:
	if not cont or cont.get_child_count() == 0:
		return
	var wrapper_node: Node = pivot.get_parent()
	var k: float = wrapper_node.get_meta("attachment_scale", 1.0) if wrapper_node else 1.0
	var front := -1.0 if float(cfg.get("socket_muzzle", Vector3(0, 0, -1)).z) < 0.0 else 1.0
	var pts := PackedVector3Array()
	for m in pivot.find_children("*", "MeshInstance3D", true, false):
		if cont.is_ancestor_of(m) or m.mesh == null or not _visible_in(m, pivot):
			continue
		var xf := _xf_to(m, pivot)
		for sidx in m.mesh.get_surface_count():
			for v in m.mesh.surface_get_arrays(sidx)[Mesh.ARRAY_VERTEX]:
				pts.append(xf * v)
	if pts.is_empty():
		return
	var gb := AABB(pts[0], Vector3.ZERO)
	for p in pts: gb = gb.expand(p)
	var gun_front: float = gb.position.z if front < 0 else gb.end.z
	var gun_rear: float = gb.end.z if front < 0 else gb.position.z
	# boca do cano registrada (modelos em que a peça mais à frente não é o cano, ex.: MP7 com lanterna)
	var tip_override := false
	var tip_c := Vector3.ZERO
	if cfg.has("muzzle_tip"):
		for m in pivot.find_children("*", "MeshInstance3D", true, false):
			if not cont.is_ancestor_of(m) and String(m.name).to_lower().begins_with("receiver"):
				tip_c = _xf_to(m, pivot) * (cfg["muzzle_tip"] as Vector3)
				gun_front = tip_c.z
				tip_override = true
				break
	# ponta do cano: centro e raio pelos vértices reais da boca
	var tip_x := []; var tip_y := []
	for p in pts:
		if absf(p.z - gun_front) < 0.015 and (not tip_override or Vector2(p.x - tip_c.x, p.y - tip_c.y).length() < 0.03 * k):
			tip_x.append(p.x); tip_y.append(p.y)
	var muzzle_front: float = gun_front
	var barrel_node: Node3D = cont.get_node_or_null("Att_barrel") as Node3D
	if barrel_node and tip_x.size() > 3:
		tip_x.sort(); tip_y.sort()
		var cx: float = tip_c.x if tip_override else float(tip_x[tip_x.size() / 2])
		var cy: float = tip_c.y if tip_override else float(tip_y[tip_y.size() / 2])
		var dists := []
		for i in tip_x.size():
			dists.append(Vector2(float(tip_x[i]) - cx, float(tip_y[i]) - cy).length())
		dists.sort()
		# núcleo do cano (parte mais estreita da boca), sem freios/quebra-chamas largos
		var r: float = clampf(float(dists[int(dists.size() * 0.35)]), 0.006 * k, 0.016 * k)
		var L: float = 0.08 * k  # 8 cm reais de cano a mais
		for ch in barrel_node.get_children():
			ch.free()
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.09, 0.09, 0.10)
		mat.metallic = 0.85
		mat.roughness = 0.38
		var tube := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = r; cm.bottom_radius = r; cm.height = L; cm.radial_segments = 20
		cm.material = mat
		tube.mesh = cm
		tube.basis = Basis(Vector3.RIGHT, PI / 2.0)
		tube.position = Vector3(cx, cy, gun_front + front * (L * 0.5 - 0.004 * k))
		barrel_node.add_child(tube)
		var crown := MeshInstance3D.new()
		var rm := CylinderMesh.new()
		rm.top_radius = r * 1.18; rm.bottom_radius = r * 1.18; rm.height = 0.012 * k; rm.radial_segments = 20
		rm.material = mat
		crown.mesh = rm
		crown.basis = Basis(Vector3.RIGHT, PI / 2.0)
		crown.position = Vector3(cx, cy, gun_front + front * (L - 0.006 * k))
		barrel_node.add_child(crown)
		barrel_node.position = Vector3.ZERO
		muzzle_front = gun_front + front * L
	# centro lateral da arma e pente original (mesmo escondido) para encaixar pente/empunhadura/cabo
	var xs_all := []
	for p in pts: xs_all.append(p.x)
	xs_all.sort()
	var cx: float = float(xs_all[xs_all.size() / 2])
	var mag := _mag_info(pivot, cont, k)
	for a in cont.get_children():
		if not (a is Node3D): continue
		if String(a.get_meta("slot", "")) == "barrel": continue
		var ab := AABB(); var first := true
		for m in a.find_children("*", "MeshInstance3D", true, false):
			if m.mesh == null: continue
			var b: AABB = _xf_to(m, pivot) * m.get_aabb()
			ab = b if first else ab.merge(b); first = false
		if first: continue
		var a_rear: float = ab.end.z if front < 0 else ab.position.z
		var a_front: float = ab.position.z if front < 0 else ab.end.z
		match String(a.get_meta("slot", "")):
			"optic":
				snap_optic_to_rail(pivot, a)
			"muzzle":
				# começa na ponta do cano (0,5 cm de sobreposição para não ver fresta)
				a.position.z += (muzzle_front - front * 0.005 * k) - a_rear
				# e fica no eixo do cano: centro (mediana) dos pontos da ponta do cano
				var ys := []; var xs := []
				for p in pts:
					if absf(p.z - gun_front) < 0.015:
						ys.append(p.y); xs.append(p.x)
				if tip_override:
					var c0 := ab.get_center()
					a.position.y += tip_c.y - c0.y
					a.position.x += tip_c.x - c0.x
				elif ys.size() > 3:
					ys.sort(); xs.sort()
					var c := ab.get_center()
					a.position.y += float(ys[ys.size() / 2]) - c.y
					a.position.x += float(xs[xs.size() / 2]) - c.x
			"stock":
				# encosta na traseira do corpo (1 cm de sobreposição) e alinha o topo com o topo da traseira
				a.position.z += (gun_rear + front * 0.01 * k) - a_front
				var rear_top := -INF
				for p in pts:
					var du: float = (p.z - gun_rear) * front   # >0 = para dentro da arma
					if du >= 0.0 and du < 0.035 * k and absf(p.x - cx) < 0.03 * k and p.y > rear_top:
						rear_top = p.y
				# coronha maior que a traseira da arma (ex.: escopeta de cano serrado): reduz proporcionalmente
				var rear_lo := INF
				for p in pts:
					var du2: float = (p.z - gun_rear) * front
					if du2 >= 0.0 and du2 < 0.06 * k and absf(p.x - cx) < 0.04 * k and p.y < rear_lo:
						rear_lo = p.y
				if rear_top != -INF and rear_lo != INF and ab.size.y > 1.3 * (rear_top - rear_lo):
					var f: float = clampf(1.15 * (rear_top - rear_lo) / ab.size.y, 0.45, 1.0)
					var anchor := Vector3(ab.get_center().x, ab.end.y, a_front)
					a.scale *= f
					a.position = anchor + (a.position - anchor) * f
					ab = AABB(anchor + (ab.position - anchor) * f, ab.size * f)
				if rear_top != -INF:
					a.position.y += (rear_top - 0.004 * k) - ab.end.y
				a.position.x += cx - ab.get_center().x
			"mag":
				if (String(cfg.get("category", "")) == "secondary" or String(cfg.get("grip_side", "")) == "mag") and not mag.is_empty():
					_fit_pistol_mag(pivot, cont, a, mag, k)
				else:
					_fit_mag(a, ab, mag, pts, cx, front, k)
			"underbarrel":
				_fit_underbarrel(a, ab, pts, mag, cx, front, k, gun_front, cfg)
			"grip":
				_fit_rear_grip(a, pts, mag, cx, front, k, cfg)

# ── ENCAIXE DE PENTE / EMPUNHADURA / CABO PELA GEOMETRIA DO MODELO ───────────
## Pente original (malha "Magazine*", mesmo escondida): topo, fundo e inclinação, no espaço do Pivot
static func _mag_info(pivot: Node3D, cont: Node3D, k: float) -> Dictionary:
	var mp := PackedVector3Array()
	for m in pivot.find_children("*", "MeshInstance3D", true, false):
		if cont.is_ancestor_of(m) or m.mesh == null:
			continue
		if not String(m.name).to_lower().begins_with("magazine"):
			continue
		var xf := _xf_to(m, pivot)
		for s in m.mesh.get_surface_count():
			for v in m.mesh.surface_get_arrays(s)[Mesh.ARRAY_VERTEX]:
				mp.append(xf * v)
	if mp.size() < 8:
		return {}
	var lo := INF; var hi := -INF; var zlo := INF; var zhi := -INF; var xlo := INF; var xhi := -INF
	for p in mp:
		lo = minf(lo, p.y); hi = maxf(hi, p.y); zlo = minf(zlo, p.z); zhi = maxf(zhi, p.z); xlo = minf(xlo, p.x); xhi = maxf(xhi, p.x)
	var h := hi - lo
	var top := Vector3.ZERO; var nt := 0; var bot := Vector3.ZERO; var nb := 0
	for p in mp:
		if p.y > hi - 0.15 * h: top += p; nt += 1
		if p.y < lo + 0.15 * h: bot += p; nb += 1
	top /= maxi(nt, 1); bot /= maxi(nb, 1)
	# pente "normal" (alto, fino, embaixo da arma); tambores, caixas laterais e tubos usam o encaixe antigo
	var normal := h > 0.06 * k and (xhi - xlo) < 0.07 * k and h > 0.5 * (zhi - zlo)
	return {"top": Vector3(top.x, hi, top.z), "bottom": bot, "lo": lo, "hi": hi, "zlo": zlo, "zhi": zhi, "xlo": xlo, "xhi": xhi, "normal": normal}

## Gira e posiciona um acessório de modo que o eixo -Y local aponte para d (no plano y-z)
static func _tilt_to(a: Node3D, d: Vector3, k: float, extra: Basis = Basis.IDENTITY, scl: Vector3 = Vector3.ONE) -> void:
	d.x = 0.0
	d = d.normalized()
	var th := atan2(-d.z, -d.y)
	a.basis = Basis(Vector3.RIGHT, th) * extra * Basis.from_scale(scl * k)

static func _fit_mag(a: Node3D, ab: AABB, mag: Dictionary, pts: PackedVector3Array, cx: float, front: float, k: float) -> void:
	if not mag.is_empty() and bool(mag["normal"]):
		# mesmo topo e mesma inclinação do pente original
		var d: Vector3 = (mag["bottom"] as Vector3) - (mag["top"] as Vector3)
		var ang := rad_to_deg(atan2(-d.z, -d.y))
		if absf(ang) > 35.0:
			d = Vector3(0, -1, 0).rotated(Vector3.RIGHT, deg_to_rad(clampf(ang, -35.0, 35.0)))
		# tamanho pelo pente original (a escala dos acessórios não bate com a de todos os modelos)
		a.transform = Transform3D.IDENTITY
		var mesh_len: float = maxf(_node_aabb_local(a).size.y, 0.01)
		var orig_len: float = (float(mag["hi"]) - float(mag["lo"])) / maxf(absf(d.normalized().y), 0.5)
		var factor := 1.45 if String(a.get_meta("attachment_id", "")) in ["mag_extended", "extended"] else 1.05
		_tilt_to(a, d, 1.0, Basis.IDENTITY, Vector3.ONE * (orig_len * factor / mesh_len))
		a.position = mag["top"]
		return
	# sem pente reconhecível: topo encosta no fundo da arma naquele ponto (entra 2 cm no poço)
	var zc := ab.get_center().z
	var half := maxf(ab.size.z * 0.5, 0.015)
	var bottom := INF
	for p in pts:
		if absf(p.z - zc) <= half and absf(p.x - ab.get_center().x) < 0.05 and p.y < bottom:
			bottom = p.y
	if bottom != INF:
		a.position.y += (bottom + 0.02 * k) - ab.end.y

## Pistola: o pente fica dentro do cabo; mostra o pente original e uma extensão abaixo do cabo
static func _fit_pistol_mag(pivot: Node3D, cont: Node3D, a: Node3D, mag: Dictionary, k: float) -> void:
	for m in pivot.find_children("*", "MeshInstance3D", true, false):
		if not cont.is_ancestor_of(m) and String(m.name).to_lower().begins_with("magazine"):
			var n: Node = m
			while n and n != pivot:
				if n is Node3D: (n as Node3D).visible = true
				n = n.get_parent()
	for m in a.find_children("*", "MeshInstance3D", true, false):
		(m as MeshInstance3D).visible = false
	var ext: bool = String(a.get_meta("attachment_id", "")) in ["mag_extended", "extended"]
	var top: Vector3 = mag["top"]
	var bot: Vector3 = mag["bottom"]
	var axis: Vector3 = (bot - top)
	axis.x = 0.0
	var mag_len: float = axis.length()
	axis = axis.normalized()
	var w: float = float(mag["xhi"]) - float(mag["xlo"])
	# espessura do pente perpendicular ao eixo (no plano y-z), medida pelos limites em z
	var d: float = clampf(absf(float(mag["zhi"]) - float(mag["zlo"])) - mag_len * absf(axis.z), 0.012 * k, 0.05 * k)
	var h: float = mag_len * (0.32 if ext else 0.12)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.07, 0.07, 0.075) if ext else Color(0.55, 0.47, 0.40)
	mat.roughness = 0.8
	a.transform = Transform3D.IDENTITY
	var th := atan2(-axis.z, -axis.y)
	var holder := Node3D.new()
	holder.basis = Basis(Vector3.RIGHT, th)
	holder.position = bot
	a.add_child(holder)
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new(); bm.size = Vector3(w * 0.92, h, d * 0.92); bm.material = mat
	body.mesh = bm
	holder.add_child(body)
	body.position = Vector3(0, -h * 0.5 + 0.002 * k, 0)
	var plate := MeshInstance3D.new()
	var pm := BoxMesh.new(); pm.size = Vector3(w * 1.05, 0.004 * k, d * 1.1); pm.material = mat
	plate.mesh = pm
	holder.add_child(plate)
	plate.position = Vector3(0, -h - 0.001 * k, 0)

## Fundo da arma (menor y) numa fatia estreita, perto da linha central
static func _bottom_at(pts: PackedVector3Array, z: float, cx: float, hz: float, hx: float) -> float:
	var b := INF
	for p in pts:
		if absf(p.z - z) <= hz and absf(p.x - cx) <= hx and p.y < b:
			b = p.y
	return b

static func _fit_underbarrel(a: Node3D, ab: AABB, pts: PackedVector3Array, mag: Dictionary, cx: float, front: float, k: float, gun_front: float, cfg: Dictionary) -> void:
	# deitar a peça ao longo do cano (os modelos vêm com o comprimento no eixo X)
	var rot := Basis(Vector3.UP, PI * 0.5)
	a.basis = rot * Basis.from_scale(Vector3.ONE * k)
	# eixo do cano: centro da boca
	var ys := []
	for p in pts:
		if absf(p.z - gun_front) < 0.015 * k and absf(p.x - cx) < 0.03 * k:
			ys.append(p.y)
	ys.sort()
	var bore: float = float(ys[ys.size() / 2]) if ys.size() > 0 else 0.0
	# guarda-mão: da boca para trás, primeiro trecho em que o fundo fica bem abaixo do cano
	var step := 0.01 * k
	var hg_front := INF; var hg_bot := INF; var hg_rear := INF
	var limit_u: float = (minf(mag["zlo"], mag["zhi"]) if front < 0 else maxf(mag["zlo"], mag["zhi"])) if not mag.is_empty() else gun_front - front * 0.4 * k
	var z := gun_front - front * step
	for i in 80:
		if (z - limit_u) * front <= 0.0:
			break
		var bt := _bottom_at(pts, z, cx, step * 0.5, 0.02 * k)
		if bt != INF:
			if hg_front == INF:
				if bt < bore - 0.022 * k and bt > bore - float(cfg.get("ub_max_drop", 0.12)) * k:
					hg_front = z; hg_bot = bt
			else:
				if absf(bt - hg_bot) > 0.03 * k:
					break
				hg_rear = z
		z -= front * step
	var zp: float
	if hg_front != INF and hg_rear != INF and absf(hg_front - hg_rear) > 0.04 * k:
		var length := absf(hg_front - hg_rear)
		zp = hg_front - front * maxf(0.3 * length, 0.03 * k)
	else:
		zp = (cfg.get("socket_underbarrel", Vector3(0, 0, -0.13)) as Vector3).z * k
	# recalcula a caixa com a rotação nova e encosta o topo no fundo do guarda-mão (sem fresta)
	a.position = Vector3.ZERO
	var nb := _node_aabb_local(a)
	var bt2 := _bottom_at(pts, zp, cx, maxf(nb.size.z * 0.35, 0.006 * k), 0.015 * k)
	if bt2 == INF or bt2 < bore - float(cfg.get("ub_max_drop", 0.12)) * k:
		bt2 = bore - 0.03 * k
	a.position = Vector3(cx - nb.get_center().x, bt2 + 0.002 * k - nb.end.y, zp - nb.get_center().z)

## Caixa das malhas de um acessório no espaço do pai dele (com a transformação atual do acessório)
static func _node_aabb_local(a: Node3D) -> AABB:
	var ab := AABB(); var first := true
	for m in a.find_children("*", "MeshInstance3D", true, false):
		if m.mesh == null: continue
		var xf := a.transform * _xf_to(m, a)
		var bb: AABB = xf * m.get_aabb()
		ab = bb if first else ab.merge(bb); first = false
	return ab

static func _fit_rear_grip(a: Node3D, pts: PackedVector3Array, mag: Dictionary, cx: float, front: float, k: float, cfg: Dictionary = {}) -> void:
	if mag.is_empty():
		return
	var hi: float = mag["hi"]; var lo: float = mag["lo"]
	var u0: float = minf(mag["zlo"] * front, mag["zhi"] * front)   # traseira do pente (coordenada "para frente")
	var u1: float = maxf(mag["zlo"] * front, mag["zhi"] * front)
	var best := {}
	# pente dentro do cabo (pistolas, MP7): há carcaça mais larga que o pente em volta da metade de baixo dele
	var shell := 0
	var xlo: float = mag["xlo"]; var xhi: float = mag["xhi"]
	for p in pts:
		var u := p.z * front
		if u >= u0 and u <= u1 and p.y < hi - 0.5 * (hi - lo) and p.y > lo and (p.x < xlo - 0.002 * k or p.x > xhi + 0.002 * k):
			shell += 1
	# lado do cabo: atrás do pente (padrão) ou na frente (bullpups)
	var sides := [-1.0] if String(cfg.get("grip_side", "rear")) == "rear" else [1.0]
	if shell > 30 or String(cfg.get("grip_side", "")) == "mag":
		sides = []
		shell = 99
	for side in sides:
		var ua: float = (u0 - 0.15 * k) if side < 0 else (u1 + 0.004 * k)
		var ub: float = (u0 - 0.004 * k) if side < 0 else (u1 + 0.15 * k)
		var bottom := INF
		for p in pts:
			var u := p.z * front
			if u >= ua and u <= ub and absf(p.x - cx) < 0.03 * k and p.y < bottom:
				bottom = p.y
		if bottom != INF and (best.is_empty() or bottom < float(best["bottom"])):
			best = {"ua": ua, "ub": ub, "bottom": bottom}
	# cabo que envolve o pente (pistolas, MP7): usa a faixa do próprio pente
	if best.is_empty() or (shell > 30) or float(best["bottom"]) > lo + 0.5 * (hi - lo):
		best = {"ua": u0 - 0.01 * k, "ub": u1 + 0.01 * k, "bottom": lo}
	# eixo medido só na parte de baixo do cabo (o guarda-mato fica em cima e puxaria para a frente)
	var top_cut: float = float(best["bottom"]) + 0.55 * (hi - float(best["bottom"]))
	var top_y: float = float(best["bottom"]) + 0.85 * (hi - float(best["bottom"]))
	var c := Vector2.ZERO; var n := 0
	var sel := []
	for p in pts:
		var u := p.z * front
		if u >= float(best["ua"]) and u <= float(best["ub"]) and absf(p.x - cx) < 0.03 * k and p.y < top_cut:
			sel.append(Vector2(p.z, p.y)); c += Vector2(p.z, p.y); n += 1
	if n < 6:
		return
	c /= n
	var szz := 0.0; var syy := 0.0; var szy := 0.0
	for q in sel:
		var dq: Vector2 = q - c
		szz += dq.x * dq.x; syy += dq.y * dq.y; szy += dq.x * dq.y
	var ang := 0.5 * atan2(2.0 * szy, szz - syy)
	var ax := Vector2(cos(ang), sin(ang))
	if absf(ax.y) < 0.5:   # eixo principal deitado: não é um cabo; assume vertical
		ax = Vector2(0, -1)
	if ax.y > 0: ax = -ax  # para baixo
	var lmin := INF; var lmax := -INF
	for q in sel:
		var t: float = (q - c).dot(ax)
		lmin = minf(lmin, t); lmax = maxf(lmax, t)
	# estende o topo ao longo do eixo até a altura em que o cabo encontra o corpo
	if absf(ax.y) > 0.2:
		lmin = minf(lmin, (top_y - c.y) / ax.y)
	var length := lmax - lmin
	var d := Vector3(0, ax.y, ax.x)
	var s_len := clampf(length / (0.105 * k), 0.75, 1.3)
	# a malha do cabo vem com a largura no eixo X: gira 90° para o comprimento ficar ao longo da arma
	var side_scl := 2.1 if shell > 30 else 1.25   # cabo em volta do pente: capa mais grossa por fora
	_tilt_to(a, d, k, Basis(Vector3.UP, PI * 0.5), Vector3(1.08, s_len, side_scl))
	var top2: Vector2 = c + ax * lmin
	a.position = Vector3(cx, top2.y, top2.x)

# ── RECORTE DE PEÇAS FUNDIDAS NA MALHA DO CORPO ─────────────────────────────
# cfg["cuts"] = [{"slot": "stock", "mesh": "receiver", "min": Vector3, "max": Vector3}, ...] (espaço do mesh "receiver*")
static func _apply_body_cuts(pivot: Node3D, cfg: Dictionary, active: Array) -> void:
	if not cfg.has("cuts"):
		return
	var ref: MeshInstance3D = null
	for m in pivot.find_children("*", "MeshInstance3D", true, false):
		if String(m.name).to_lower().begins_with("receiver") and (m.get_parent() == null or String(m.get_parent().name) != "AttachmentContainer"):
			ref = m; break
	if not ref:
		return
	var to_ref_base := _xf_to(ref, pivot).affine_inverse()
	var by_mesh := {}
	for c in cfg["cuts"]:
		var mn: String = String(c.get("mesh", "receiver")).to_lower()
		if not by_mesh.has(mn): by_mesh[mn] = []
		if String(c["slot"]) in active:
			by_mesh[mn].append(AABB(c["min"], (c["max"] as Vector3) - (c["min"] as Vector3)))
	for m in pivot.find_children("*", "MeshInstance3D", true, false):
		var key := String(m.name).to_lower()
		var hit := ""
		for mn in by_mesh.keys():
			if key.begins_with(mn): hit = mn; break
		if hit == "":
			continue
		if not m.has_meta("_orig_mesh"):
			m.set_meta("_orig_mesh", m.mesh)
		m.visible = true   # peça com recorte configurado: o recorte esconde só a parte trocada
		var orig: Mesh = m.get_meta("_orig_mesh")
		var boxes: Array = by_mesh[hit]
		if boxes.is_empty():
			m.mesh = orig
			continue
		var to_ref: Transform3D = to_ref_base * _xf_to(m, pivot)
		var out := ArrayMesh.new()
		for s in orig.get_surface_count():
			var mdt := MeshDataTool.new()
			if mdt.create_from_surface(orig, s) != OK:
				continue
			var st := SurfaceTool.new(); st.begin(Mesh.PRIMITIVE_TRIANGLES)
			var kept := 0
			for f in mdt.get_face_count():
				var cen := Vector3.ZERO
				for kk in 3: cen += to_ref * mdt.get_vertex(mdt.get_face_vertex(f, kk))
				cen /= 3.0
				var cut := false
				for bx in boxes:
					if (bx as AABB).has_point(cen): cut = true; break
				if cut: continue
				kept += 1
				for kk in 3:
					var vi := mdt.get_face_vertex(f, kk)
					st.set_normal(mdt.get_vertex_normal(vi))
					st.set_uv(mdt.get_vertex_uv(vi))
					st.add_vertex(mdt.get_vertex(vi))
			if kept > 0:
				st.commit(out)
				out.surface_set_material(out.get_surface_count() - 1, orig.surface_get_material(s))
		m.mesh = out

# ── AJUSTES DAS PEÇAS (modelos com orientação/material errados) ───────────────
static func _decorate_attachment(node: Node3D, att_id: String) -> void:
	match att_id:
		"grip_rubber", "grip_stippled":
			var mat := StandardMaterial3D.new()
			mat.albedo_color = Color(0.07, 0.07, 0.075) if att_id == "grip_rubber" else Color(0.16, 0.15, 0.13)
			mat.roughness = 0.85 if att_id == "grip_rubber" else 0.95
			for m in node.find_children("*", "MeshInstance3D", true, false):
				(m as MeshInstance3D).material_override = mat
		"optic_sniper", "sniper":
			_build_scope(node)

## Luneta montada por código: o modelo original é uma peça de 6 cm que não parece luneta.
## Eixo da luneta na altura do retículo do jogo (y = 0,018) para a mira continuar exata.
static func _build_scope(node: Node3D) -> void:
	for m in node.find_children("*", "MeshInstance3D", true, false):
		if String(m.name) == "Body":
			(m as MeshInstance3D).visible = false
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.08, 0.08, 0.085)
	mat.metallic = 0.55
	mat.roughness = 0.45
	var axis_y := 0.018
	var parts := [
		# [raio frente, raio trás, z início, z fim]
		[0.0185, 0.0185, -0.205, -0.165],  # sino da objetiva
		[0.0185, 0.0125, -0.165, -0.135],  # cone
		[0.0125, 0.0125, -0.135, 0.045],   # tubo
		[0.0125, 0.0155, 0.045, 0.065],    # cone da ocular
		[0.0155, 0.0155, 0.065, 0.100],    # ocular
	]
	for pr in parts:
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = pr[0]; cm.bottom_radius = pr[1]; cm.height = float(pr[3]) - float(pr[2])
		cm.radial_segments = 24; cm.cap_top = false; cm.cap_bottom = false
		cm.material = mat
		mi.mesh = cm
		mi.rotation = Vector3(-PI * 0.5, 0, 0)   # eixo Y do cilindro -> -Z: topo (top_radius) para a frente
		mi.position = Vector3(0, axis_y, (float(pr[2]) + float(pr[3])) * 0.5)
		node.add_child(mi)
	# torres de elevação e deriva
	for t in [[Vector3(0, axis_y + 0.017, -0.035), Vector3.ZERO], [Vector3(0.017, axis_y, -0.035), Vector3(0, 0, PI * 0.5)]]:
		var tm := MeshInstance3D.new()
		var tc := CylinderMesh.new()
		tc.top_radius = 0.008; tc.bottom_radius = 0.008; tc.height = 0.012; tc.radial_segments = 16
		tc.material = mat
		tm.mesh = tc; tm.position = t[0]; tm.rotation = t[1]
		node.add_child(tm)
	# anéis e base no trilho
	for z in [-0.095, 0.015]:
		var bm := MeshInstance3D.new()
		var bx := BoxMesh.new()
		bx.size = Vector3(0.022, 0.012, 0.014); bx.material = mat
		bm.mesh = bx; bm.position = Vector3(0, 0.006, z)
		node.add_child(bm)

# ── APLICAÇÃO DE CAMUFLAGEM PBR E RESTAURAÇÃO BASE ────────────────────────────
static func apply_camo(wrapper: Node3D, camo_key: String) -> void:
	if not wrapper:
		return

	# Se for o padrão "Militar Padrão" ou vazio, restaurar os materiais originais autênticos
	if camo_key == "default" or camo_key.is_empty():
		_restore_materials_recursive(wrapper)
		return

	var mat: StandardMaterial3D = null
	match camo_key:
		"gold":
			mat = StandardMaterial3D.new()
			mat.albedo_color = Color(1.0, 0.82, 0.25)
			mat.metallic = 0.95
			mat.roughness = 0.18
			mat.emission_enabled = true
			mat.emission = Color(0.4, 0.3, 0.05)
		"dark_matter":
			mat = StandardMaterial3D.new()
			mat.albedo_color = Color(0.18, 0.05, 0.32)
			mat.metallic = 0.8
			mat.roughness = 0.2
			mat.emission_enabled = true
			mat.emission = Color(0.65, 0.1, 0.85)
			mat.emission_energy_multiplier = 1.6
		"carbon":
			mat = StandardMaterial3D.new()
			mat.albedo_color = Color(0.14, 0.15, 0.18)
			mat.metallic = 0.5
			mat.roughness = 0.35
		_:
			_restore_materials_recursive(wrapper)
			return

	_apply_material_recursive(wrapper, mat)

static func _cache_base_materials_recursive(node: Node) -> void:
	if node is MeshInstance3D:
		var mi = node as MeshInstance3D
		mi.set_meta("base_material_override", mi.material_override)
	for child in node.get_children():
		_cache_base_materials_recursive(child)

static func _restore_materials_recursive(node: Node) -> void:
	if node is MeshInstance3D:
		var mi = node as MeshInstance3D
		if mi.has_meta("base_material_override"):
			mi.material_override = mi.get_meta("base_material_override")
		else:
			mi.material_override = null
	for child in node.get_children():
		_restore_materials_recursive(child)

static func _apply_material_recursive(node: Node, mat: Material) -> void:
	if node is MeshInstance3D and node.visible:
		# Não substituir lentes de vidro ou leds de mira para manter retículos visíveis
		var n_low = node.name.to_lower()
		if not ("glass" in n_low or "lens" in n_low or "reticle" in n_low or "led" in n_low):
			node.material_override = mat
	for child in node.get_children():
		_apply_material_recursive(child, mat)

# ── UTILITÁRIOS INTERNOS ──────────────────────────────────────────────────────
static func _clean_arms_recursive(node: Node) -> void:
	if node is MeshInstance3D:
		var n_low = node.name.to_lower()
		var m_name = node.mesh.resource_name.to_lower() if node.mesh else ""
		if "arm" in n_low or "hand" in n_low or "pole" in n_low or "wrist" in n_low or "arm" in m_name:
			node.visible = false
	for child in node.get_children():
		_clean_arms_recursive(child)

static func _calc_visible_mesh_aabb(root: Node3D) -> AABB:
	var total = AABB()
	var first = true
	var stack: Array = [[root, root.transform]]
	while not stack.is_empty():
		var item: Array = stack.pop_back()
		var curr = item[0]
		var tf: Transform3D = item[1]
		if curr is MeshInstance3D and curr.visible and curr.mesh:
			var mi = curr as MeshInstance3D
			var mesh_aabb = tf * mi.get_aabb()
			if first:
				total = mesh_aabb
				first = false
			else:
				total = total.merge(mesh_aabb)
		for c in curr.get_children():
			if c is Node3D:
				stack.append([c, tf * c.transform])
			else:
				stack.append([c, tf])
	return total
